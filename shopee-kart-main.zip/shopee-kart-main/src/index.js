import * as cartService from "./services/cart.js"
import createItem from "./services/item.js";

const myCart = [];
const myWishList = [];

console.log("Welcome to your shoppe kart\n");

const item1 = await createItem("Hotwheels ferrari", 20.99, 1);
const item2 = await createItem("hotwheels lamborguini", 39.99, 3);
// adicionando item no carrinho
await cartService.addItem(myCart, item1);
await cartService.addItem(myCart, item2);

await cartService.removeItem(myCart, item2);
await cartService.removeItem(myCart, item2);
await cartService.removeItem(myCart, item2);
await cartService.displayCart(myCart);
// deletando item do carrinho
// await cartService.deleteItem(myCart, item1.name);
// await cartService.deleteItem(myCart, item2.name);

await cartService.calculateTotal(myCart);