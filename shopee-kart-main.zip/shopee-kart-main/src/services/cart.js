//quais ações meu carrinho pode fazer?
// casos de usos
// adicionar item✅
 async function addItem(userCart, item) {
    userCart.push(item);
 }

//calcular o total
async function calculateTotal(userCart) {
    console.log("\nshoppe kart TOTAL IS:");
    const result = userCart.reduce((total, item)=> total + item.subtotal(), 0);
    console.log(`🎁 TOTAL: ${result}`);
}

// deletar item do carrinho
async function deleteItem(userCart, name){
     const index = userCart.findIndex((item) => item.name === name);
     if(index !== -1) {
        userCart.splice(index,1);
     }
}
// remover um item ✅
// ✅ verifica se o indíce é maior que 0, e se é menor do que o tamanho do carrinho 
async function removeItem(userCart, item) {
    //1. encontrar o indice do item
    const indexFound = userCart.findIndex((p) => p.name === item.name);
    // 2. Caso não encontre o item
    if(indexFound == -1) {
        console.log("item não encontrado");
        return;
    }
    //3.item -1 subtrair um item, item = 1 deletar o item
    if(userCart[indexFound].quantity > 1) {
        userCart[indexFound].quantity -= 1;
        return;
    } 
    //4. caso item = 1 deletar o item
    if(userCart[indexFound].quantity ==1) {
        userCart.splice(indexFound, 1);
        return;
    }
}

// Exibir o carrinho do usuário
async function displayCart(userCart) {
    console.log("Shopee cart list:")
    userCart.forEach((item, index) =>{
        console.log(`\n${index + 1}.${item.name} - R$ ${item.price} | ${item.quantity}x | Subtotal = ${item.subtotal()}`);
    });
}

export {
    addItem,
    calculateTotal,
    deleteItem,
    removeItem,
    displayCart
}